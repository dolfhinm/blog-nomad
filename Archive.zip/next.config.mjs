/** @type {import('next').NextConfig} */
const nextConfig = {
  // Minimal config. Extend as needed.
}
export default nextConfig
